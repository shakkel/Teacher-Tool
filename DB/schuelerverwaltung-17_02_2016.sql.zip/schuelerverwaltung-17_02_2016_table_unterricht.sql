
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `unterricht`
--

CREATE TABLE `unterricht` (
  `u_id` int(11) NOT NULL,
  `kz_id` int(11) DEFAULT NULL,
  `ku_id` int(11) DEFAULT NULL,
  `lf_id` int(11) NOT NULL,
  `r_kuerzel` varchar(10) NOT NULL,
  `u_tag` int(11) NOT NULL,
  `u_stunde` int(11) NOT NULL,
  `u_doppelstunde` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `unterricht`
--

INSERT INTO `unterricht` (`u_id`, `kz_id`, `ku_id`, `lf_id`, `r_kuerzel`, `u_tag`, `u_stunde`, `u_doppelstunde`) VALUES
(22, 3273, NULL, 2, 'g8', 3, 1, 1),
(23, 3274, NULL, 2, 'g123', 3, 3, 1);
