
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `unterrichtsstunde`
--

CREATE TABLE `unterrichtsstunde` (
  `ustd_id` int(11) NOT NULL,
  `lf_id` int(11) NOT NULL,
  `kz_id` int(11) DEFAULT NULL,
  `ku_id` int(11) DEFAULT NULL,
  `ustd_datum` date NOT NULL,
  `u_stunde` int(11) NOT NULL,
  `u_doppelstunde` tinyint(1) NOT NULL DEFAULT '1',
  `ustd_text` text,
  `ustd_ausfall` tinyint(1) NOT NULL DEFAULT '0',
  `ustd_vertretungslehrer` int(11) DEFAULT NULL,
  `ustd_reserviert` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `unterrichtsstunde`
--

INSERT INTO `unterrichtsstunde` (`ustd_id`, `lf_id`, `kz_id`, `ku_id`, `ustd_datum`, `u_stunde`, `u_doppelstunde`, `ustd_text`, `ustd_ausfall`, `ustd_vertretungslehrer`, `ustd_reserviert`) VALUES
(91, 2, 3273, NULL, '2015-04-29', 1, 1, 'hallo', 0, NULL, 0),
(92, 2, 3274, NULL, '2015-04-29', 3, 1, NULL, 0, NULL, 1);
