
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kurs`
--

CREATE TABLE `kurs` (
  `ku_id` int(11) NOT NULL,
  `ku_bezeichnung` varchar(256) DEFAULT NULL,
  `zph_id` int(11) NOT NULL,
  `ku_kuerzel` varchar(10) NOT NULL,
  `lf_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
