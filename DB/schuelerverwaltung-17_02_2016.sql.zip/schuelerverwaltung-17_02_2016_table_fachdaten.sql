
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `fachdaten`
--

CREATE TABLE `fachdaten` (
  `f_kuerzel` varchar(10) NOT NULL,
  `f_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `fachdaten`
--

INSERT INTO `fachdaten` (`f_kuerzel`, `f_name`) VALUES
('DEU', 'Deutsch'),
('ENG', 'Englisch'),
('IT', 'Informatik'),
('MA', 'Mathematik'),
('NatWI', 'Naturwissenschaften'),
('Reli', 'Religion'),
('SPO', 'Sport');
