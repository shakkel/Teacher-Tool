
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ferien`
--

CREATE TABLE `ferien` (
  `fe_start` date NOT NULL,
  `fe_ende` date NOT NULL,
  `fe_bezeichnung` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `ferien`
--

INSERT INTO `ferien` (`fe_start`, `fe_ende`, `fe_bezeichnung`) VALUES
('2014-12-22', '2015-01-05', 'Weihnachtsferien'),
('2015-02-02', '2015-02-03', 'Winterferien'),
('2015-03-25', '2015-04-10', 'Osterferien'),
('2015-05-15', '2015-05-26', 'Pfingstferien'),
('2015-07-23', '2015-09-02', 'Sommerferien'),
('2015-10-19', '2015-10-31', 'Herbstferien'),
('2015-12-23', '2016-01-06', 'Weihnachtsferien');
