
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hausaufgabe`
--

CREATE TABLE `hausaufgabe` (
  `ha_id` int(11) NOT NULL,
  `lf_id` int(11) NOT NULL,
  `kz_id` int(11) NOT NULL,
  `ha_frist` date NOT NULL,
  `ha_text` text NOT NULL,
  `ha_abgeschlossen` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
