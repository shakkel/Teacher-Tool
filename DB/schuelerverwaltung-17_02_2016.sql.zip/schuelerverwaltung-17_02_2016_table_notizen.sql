
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `notizen`
--

CREATE TABLE `notizen` (
  `no_id` int(11) NOT NULL,
  `no_typ` enum('schueler','klasse_zeitphase','raum','lehrer') NOT NULL,
  `no_fremd_id` int(11) NOT NULL,
  `no_text` text NOT NULL,
  `l_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `notizen`
--

INSERT INTO `notizen` (`no_id`, `no_typ`, `no_fremd_id`, `no_text`, `l_id`) VALUES
(13, 'lehrer', 1, 'Nicht vergessen: Punkt- vor Strichrechnung!', 1);
