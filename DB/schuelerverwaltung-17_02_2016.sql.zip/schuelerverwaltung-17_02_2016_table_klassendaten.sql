
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `klassendaten`
--

CREATE TABLE `klassendaten` (
  `k_kuerzel` varchar(10) NOT NULL,
  `k_bezeichnung` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `klassendaten`
--

INSERT INTO `klassendaten` (`k_kuerzel`, `k_bezeichnung`) VALUES
('FOT2B', 'Fachhochschule Informatik'),
('MKP1A', 'einjährige Berufsfachschule - Bautechnik'),
('MKP2A', 'Berufsschule (Ausbildungsberuf: Industriemechaniker)');
