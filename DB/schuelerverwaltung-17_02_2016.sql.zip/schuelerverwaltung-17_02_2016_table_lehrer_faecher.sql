
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lehrer_faecher`
--

CREATE TABLE `lehrer_faecher` (
  `lf_id` int(11) NOT NULL,
  `f_kuerzel` varchar(10) NOT NULL,
  `l_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `lehrer_faecher`
--

INSERT INTO `lehrer_faecher` (`lf_id`, `f_kuerzel`, `l_id`) VALUES
(2, 'MA', 1),
(3, 'IT', 1),
(4, 'ENG', 3),
(5, 'IT', 9),
(6, 'IT', 12),
(7, 'IT', 13),
(8, 'DEU', 6),
(9, 'NatWI', 2),
(10, 'Reli', 11),
(11, 'SPO', 14),
(12, 'IT', 15),
(13, 'SPO', 15),
(14, 'ENG', 15);
