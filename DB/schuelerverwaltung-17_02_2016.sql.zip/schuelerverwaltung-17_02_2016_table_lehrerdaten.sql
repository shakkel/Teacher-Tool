
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lehrerdaten`
--

CREATE TABLE `lehrerdaten` (
  `l_id` int(11) NOT NULL,
  `l_kuerzel` varchar(10) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `l_gebdat` date DEFAULT NULL,
  `l_str` varchar(50) DEFAULT NULL,
  `l_tel` varchar(20) DEFAULT NULL,
  `l_mobil` varchar(20) DEFAULT NULL,
  `l_mail1` varchar(30) DEFAULT NULL,
  `l_mail2` int(30) DEFAULT NULL,
  `o_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `lehrerdaten`
--

INSERT INTO `lehrerdaten` (`l_id`, `l_kuerzel`, `l_name`, `l_gebdat`, `l_str`, `l_tel`, `l_mobil`, `l_mail1`, `l_mail2`, `o_id`) VALUES
(1, 'WG', 'Wittenberg', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'EO', 'Engelke', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'RU', 'Rullhusen', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'KI', 'Krumkühler', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'MI', 'Meinold', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'ST', 'Stanke', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'LE', 'Lenz', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'SH', 'Schmitters', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'MA', '?', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'HiS', 'Hilfers', '1996-12-01', 'Igelpfad 5', '04221/123456789', NULL, 'basti.hilfers@googlemail.com', NULL, NULL);
