
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schueler_kurs`
--

CREATE TABLE `schueler_kurs` (
  `sku_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ku_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
