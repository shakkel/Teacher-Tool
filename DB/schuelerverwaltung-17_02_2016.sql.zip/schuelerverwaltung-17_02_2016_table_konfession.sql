
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `konfession`
--

CREATE TABLE `konfession` (
  `konf_id` int(11) NOT NULL,
  `konf_kuerzel` varchar(10) NOT NULL,
  `konf_bezeichnung` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `konfession`
--

INSERT INTO `konfession` (`konf_id`, `konf_kuerzel`, `konf_bezeichnung`) VALUES
(0, 'OA', 'keine Angabe'),
(1, 'EV', 'evangelisch'),
(2, 'LT', 'evangelisch-lutheris'),
(3, 'RK', 'römisch-katholisch'),
(4, 'IS', 'islamisch'),
(6, '', ''),
(7, 'SO', 'sonstige'),
(8, 'OH', 'ohne'),
(9, 'RF', 'evangelisch-reformie');
