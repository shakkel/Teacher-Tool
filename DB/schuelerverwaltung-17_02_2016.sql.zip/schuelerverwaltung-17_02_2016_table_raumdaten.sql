
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `raumdaten`
--

CREATE TABLE `raumdaten` (
  `r_kuerzel` varchar(10) NOT NULL,
  `r_kapazitaet` smallint(6) DEFAULT NULL,
  `r_info` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `raumdaten`
--

INSERT INTO `raumdaten` (`r_kuerzel`, `r_kapazitaet`, `r_info`) VALUES
('g118', 30, 'Normaler Klassenraum'),
('g119', 40, 'Klausurenraum'),
('g123', 30, 'Normaler Klassenraum'),
('g201', 27, 'PC Klassenraum'),
('g222', 30, 'Normaler Klassenraum'),
('g8', 27, 'PC Klassenraum');
