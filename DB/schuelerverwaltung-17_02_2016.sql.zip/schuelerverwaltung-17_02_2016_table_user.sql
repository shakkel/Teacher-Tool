
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `l_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`user_id`, `user`, `pass`, `admin`, `l_id`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, NULL),
(2, 'root', 'e5d9dee0892c9f474a174d3bfffb7810', 0, NULL),
(3, 'mustermann', 'c96dd568316deb9d8c7dec73b4c27cbb', 0, NULL),
(4, 'braunschweig', '81dc9bdb52d04dc20036dbd8313ed055', 1, NULL),
(5, 'hilfers', '81dc9bdb52d04dc20036dbd8313ed055', 0, 15);
