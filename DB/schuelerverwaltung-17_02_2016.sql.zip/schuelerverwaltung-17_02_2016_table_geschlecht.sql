
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `geschlecht`
--

CREATE TABLE `geschlecht` (
  `g_id` int(11) NOT NULL,
  `g_bezeichnung` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `geschlecht`
--

INSERT INTO `geschlecht` (`g_id`, `g_bezeichnung`) VALUES
(0, 'keine Angabe'),
(1, 'männlich'),
(2, 'weiblich'),
(3, 'gender');
