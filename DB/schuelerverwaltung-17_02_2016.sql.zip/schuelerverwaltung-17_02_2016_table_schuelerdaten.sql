
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schuelerdaten`
--

CREATE TABLE `schuelerdaten` (
  `s_id` int(11) NOT NULL,
  `s_nname` varchar(70) CHARACTER SET utf8mb4 NOT NULL,
  `s_vname` varchar(70) CHARACTER SET utf8mb4 NOT NULL,
  `s_gebdat` date NOT NULL DEFAULT '0000-00-00',
  `s_geb_ort` varchar(70) NOT NULL DEFAULT 'null',
  `s_plz` varchar(8) NOT NULL,
  `s_ort` varchar(70) NOT NULL,
  `s_str` varchar(70) NOT NULL,
  `s_tel` varchar(20) NOT NULL,
  `s_mobil` varchar(20) DEFAULT NULL,
  `s_fax` varchar(20) DEFAULT NULL,
  `s_mail1` varchar(70) DEFAULT NULL,
  `s_mail2` varchar(70) DEFAULT NULL,
  `s_letzter_abschluss` varchar(70) NOT NULL,
  `s_hoechster_abschluss` varchar(40) NOT NULL,
  `s_einschulung` datetime NOT NULL,
  `s_familienstand` int(11) DEFAULT NULL,
  `s_schulpflicht` int(1) NOT NULL DEFAULT '0',
  `s_bafoeg` int(1) NOT NULL DEFAULT '0',
  `s_foto` mediumblob,
  `S_foto_2` mediumtext,
  `s_erz_nname` varchar(70) DEFAULT NULL,
  `s_erz_vname` varchar(70) DEFAULT NULL,
  `s_erz_plz` varchar(8) DEFAULT NULL,
  `s_erz_ort` varchar(70) DEFAULT NULL,
  `s_erz_str` varchar(70) DEFAULT NULL,
  `s_erz_tel` varchar(20) DEFAULT NULL,
  `s_erz_fax` varchar(20) DEFAULT NULL,
  `s_erz_mobil` varchar(20) DEFAULT NULL,
  `s_erz_mail1` varchar(70) DEFAULT NULL,
  `s_erz_mail2` varchar(70) DEFAULT NULL,
  `st_id` int(11) NOT NULL,
  `g_id` int(11) DEFAULT NULL,
  `konf_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `schuelerdaten`
--

INSERT INTO `schuelerdaten` (`s_id`, `s_nname`, `s_vname`, `s_gebdat`, `s_geb_ort`, `s_plz`, `s_ort`, `s_str`, `s_tel`, `s_mobil`, `s_fax`, `s_mail1`, `s_mail2`, `s_letzter_abschluss`, `s_hoechster_abschluss`, `s_einschulung`, `s_familienstand`, `s_schulpflicht`, `s_bafoeg`, `s_foto`, `S_foto_2`, `s_erz_nname`, `s_erz_vname`, `s_erz_plz`, `s_erz_ort`, `s_erz_str`, `s_erz_tel`, `s_erz_fax`, `s_erz_mobil`, `s_erz_mail1`, `s_erz_mail2`, `st_id`, `g_id`, `konf_id`) VALUES
(6646, 'Entelmann', 'Pascal', '1994-06-29', 'Nordenham', '27753', 'Delmenhorst', 'Altenescher Ring 8', '09079-3772', '62927-4619406', NULL, NULL, NULL, 'HA', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Sadat', 'Dagmar', '27755', 'Delmenhorst', 'Tannenbergstr. 57', '32327-0300949', NULL, NULL, NULL, NULL, 0, 1, 0),
(6647, 'Wojtynek', 'Nina', '1990-01-30', 'Delmenhorst', '27749', 'Delmenhorst', 'Dompfaffweg 6', '67602-5346', '06613-3117947', NULL, NULL, NULL, 'SI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Reimann', 'Murat', NULL, NULL, 'Wildeshauser Landstr. 75', '17397-8918686', NULL, NULL, NULL, NULL, 0, 1, 1),
(6648, 'Bade', 'Finja', '1982-12-08', 'Braunschweig', '27798', 'Hude', 'Am Bookholzberg 1', '14205-1255', '78647-7901922', NULL, NULL, NULL, 'SI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Harmus', 'Susanne u. Michael', NULL, NULL, NULL, '87724-5297889', NULL, NULL, NULL, NULL, 0, 2, 1),
(6649, 'Belz', 'Lea', '1987-07-01', 'Delmenhorst', '27793', 'Wildeshausen', 'Dwostr. 15', '10267-2269', '73942-1906208', NULL, NULL, NULL, 'EI', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Klein', NULL, '27243', 'Groß Ippener', 'Schwarzdornweg 10', '05602-6788074', NULL, NULL, NULL, NULL, 0, 1, 1),
(6650, 'Böttjer', 'Cassandra', '1995-07-06', 'Delmenhorst', '27793', 'Wildeshausen', 'Rückerser Str. 17', '74812-2404', '84363-4398749', NULL, NULL, NULL, 'HA', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Hilfi', NULL, '27755', 'Delmenhorst', NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1),
(6651, 'Henneke', 'Kim-Kyra', '1973-09-21', 'Delmenhorst', '27753', 'Delmenhorst', 'Brüninger Weg 34', '37699-6702', '37093-1766664', NULL, NULL, NULL, 'HA', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Zembski-Fröhlke', 'Jörg', '27755', 'Delmenhorst', NULL, '18402-6882077', NULL, NULL, NULL, NULL, 0, 1, 0),
(6652, 'Neumann', 'Janina', '1978-06-10', 'Wildeshausen', '27751', 'Delmenhorst', 'Ring 30', '37407-0733', '92149-7933320', NULL, NULL, NULL, 'EI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Papke', 'Irene', NULL, NULL, NULL, '93352-5356161', NULL, NULL, NULL, NULL, 0, 2, 1),
(6653, 'Schmidt', 'Laura', '1995-07-19', 'Delmenhorst', '27751', 'Delmenhorst', 'Klosterdamm 20', '65211-6813', '89640-9233768', NULL, '', '', 'EI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Stelling', 'Bettina u. Burkhard', '27755', 'Delmenhorst', 'strasse', '', '', '', '', NULL, 0, 2, 6),
(6654, 'Shkolnikov', 'Jasmin', '1992-09-26', 'Bremerhaven', '27755', 'Delmenhorst', 'Am Heidberg 5', '26260-5640', '36222-0458626', NULL, NULL, NULL, 'SI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Rodewyk', NULL, '27755', 'Delmenhorst', NULL, '41070-3453757', NULL, NULL, NULL, NULL, 0, 2, 6),
(6655, 'Yilmaz', 'Saskia', '1996-01-07', 'Bremen', '27793', 'Wildeshausen', 'Am Grünen Kamp 38', '38908-2114', '07167-9762537', NULL, NULL, NULL, 'SI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Rumpczik', 'Brigitte', NULL, NULL, 'Schulstr. 21', '54179-3840401', NULL, NULL, NULL, NULL, 0, 2, 0),
(6656, 'Mari', 'Angelika', '1996-04-22', 'Delmenhorst', '27751', 'Delmenhorst', 'Bahnhofstr. 35', '93459-0928', '50817-1252904', NULL, NULL, NULL, 'HA', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '70399-3379003', NULL, NULL, NULL, NULL, 163, 1, 1),
(6657, 'Erdogan', 'Celine', '1992-10-12', 'Delmenhorst', '27749', 'Delmenhorst', 'Zaunkönigweg 14', '09589-2394', '93044-9391982', NULL, NULL, NULL, 'HK', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Schröder', NULL, NULL, NULL, NULL, '78766-0879635', NULL, NULL, NULL, NULL, 0, 1, 6),
(6658, 'Schenk', 'Malte', '1994-06-06', 'Norden', '27809', 'Lemwerder', 'Apenrader Str. 15', '36500-4925', '86016-5031890', NULL, NULL, NULL, 'HA', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Sadat', 'Natalija u. Paul', '28816', 'Stuhr', NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 3),
(6659, 'Thongphon', 'Carolin', '1994-11-22', 'Delmenhorst', '27753', 'Delmenhorst', 'Helgolandstr. 25', '71676-7826', '88127-5768176', NULL, NULL, NULL, 'SI', '', '2013-08-08 00:00:00', 0, 0, 0, NULL, NULL, 'Reimann', NULL, '27777', 'Ganderkesee', NULL, '05775-5564280', NULL, NULL, NULL, NULL, 0, 2, 1),
(6660, 'Wojtynek', 'Vanessa', '1994-06-29', 'Nordenham', '27749', 'Delmenhorst', 'Schierbroker Mühlenweg 53', '00243-0431', '66326-6084035', NULL, NULL, NULL, 'EI', '', '2014-09-11 00:00:00', 0, 0, 0, NULL, NULL, 'Harmus', 'Marina', '27793', 'Wildeshausen', NULL, '19763-8269433', NULL, NULL, NULL, NULL, 0, 1, 3),
(6661, 'Binboga', 'Kaan', '1996-07-24', 'Görlitz', '27751', 'Delmenhorst', 'Mozartstr. 35', '76059-0914', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Frick', 'Veronika u. Andreas', '27751', 'Delmenhorst', 'Estlandstr. 19', '19844-56439887', NULL, NULL, NULL, NULL, 0, 1, 1),
(6662, 'Hanke', 'Talia', '1995-09-22', 'Delmenhorst', '27749', 'Delmenhorst', 'Linoleumstr. 7', '54466-4889', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Dogan', 'Recep', '27777', 'Ganderkesee', 'Bremer Str. 300', '79346-08717047', NULL, NULL, NULL, NULL, 0, 1, 1),
(6663, 'Heumann', 'Jana', '1994-11-01', 'Delmenhorst', '28816', 'Stuhr', 'Maikuhlenweg 3', '39696-3361', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Erdmann', NULL, '27751', 'Delmenhorst', 'Detmarstr. 6', '85784-82798754', NULL, NULL, NULL, NULL, 0, 1, 1),
(6664, 'Homsy', 'Cemil Absi', '1996-06-13', 'Bremen', '27755', 'Delmenhorst', 'Oldenburger Landstr. 39', '19083-9518', '0172-1704512', NULL, NULL, NULL, 'EI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Gewald', 'Bianca u. André', NULL, NULL, NULL, '41514-12912524', NULL, NULL, NULL, NULL, 0, 1, 1),
(6665, 'Jarosch', 'Franka', '1995-11-15', 'Delmenhorst', '27804', 'Berne', 'Gesinenweg 10', '36674-8349', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Henke', 'Ilka u. Olaf', '27753', 'Delmenhorst', 'Teppichstr. 14', '94497-71759153', NULL, NULL, NULL, NULL, 0, 1, 1),
(6666, 'Jentzen', 'Vivien', '1995-07-24', 'Delmenhorst', '27755', 'Delmenhorst', 'Wissmannstr. 14', '08057-9297', NULL, NULL, NULL, NULL, 'EI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, NULL, 'Sabine u. Karl-Heinz', '27753', 'Delmenhorst', NULL, '46131-01621132', NULL, NULL, NULL, NULL, 0, 1, 1),
(6667, 'Kahl', 'Rachel', '1992-07-15', 'Bassum', '27749', 'Delmenhorst', 'Cramerstr. 123', '18277-1336', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, NULL, 'Gaby u. Ansgar', '26121', 'Oldenburg', 'Kreuzweg 4', '80677-16363800', NULL, NULL, NULL, NULL, 0, 1, 0),
(6668, 'Lockowandt', 'Jennifer', '1993-07-16', 'Bremen', '27755', 'Delmenhorst', 'Heider Ring 146 a', '68735-8589', NULL, NULL, NULL, NULL, 'EI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Michalik', NULL, '27777', 'Ganderkesee', 'Cramerstr. 69', '38309-55967523', NULL, NULL, NULL, NULL, 0, 1, 1),
(6669, 'Niehaus', 'Melissa', '1996-01-17', 'Delmenhorst', '27753', 'Delmenhorst', 'Schierbroker Str. 22 f', '04496-3201', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, NULL, 'Corinna u. Rolf von', '27804', 'Berne', 'Potsdamer Str. 8', '61772-19919205', NULL, NULL, NULL, NULL, 0, 1, 1),
(6670, 'Oetjen', 'Daniela', '1995-11-23', 'Witzenhausen', '27755', 'Delmenhorst', 'Bremer Str. 194', '53157-6990', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Puls', 'Petra', NULL, NULL, NULL, '87654-34801992', NULL, NULL, NULL, NULL, 0, 1, 3),
(6671, 'Schabio', 'Mara', '1996-03-16', 'Elbistan/Türkei', '27777', 'Ganderkesee', 'Jägerstr. 137', '13893-6729', NULL, NULL, NULL, NULL, 'FH', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, NULL, 'Andreas', NULL, NULL, 'Kornstr. 5', '42880-17646626', NULL, NULL, NULL, NULL, 0, 1, 1),
(6672, 'Schneider', 'Kim Michelle', '1996-02-22', 'Delmenhorst', '27777', 'Ganderkesee', 'Zweigstr. 2', '92340-4865', NULL, NULL, NULL, NULL, 'SI', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Lenz', 'Thomas', NULL, NULL, 'Heider Ring 92', '08633-61912989', NULL, NULL, NULL, NULL, 0, 1, 1),
(6673, 'Schriever', 'Monique', '1995-05-15', 'Görlitz', '27751', 'Delmenhorst', 'Lange Str. 1 a', '76013-7713', NULL, NULL, NULL, NULL, 'HA', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Sänger', 'Dierk', NULL, NULL, 'Berliner Str. 129 a', '64019-90481790', NULL, NULL, NULL, NULL, 163, 1, 6),
(6674, 'Schröder', 'Sarah', '1995-06-10', 'Delmenhorst', '27751', 'Delmenhorst', 'Bienenscher 10', '39922-4966', NULL, NULL, NULL, NULL, 'HA', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Scherenberg', 'Elena', NULL, NULL, 'Holzkamper Damm 9 a', '77781-05796933', NULL, NULL, NULL, NULL, 152, 1, 3),
(6675, 'Selke', 'Laura', '1995-07-10', 'Delmenhorst', '27751', 'Delmenhorst', 'Goethestr. 71', '12116-5204', NULL, NULL, NULL, NULL, 'HK', '', '2012-09-03 00:00:00', 0, 0, 0, NULL, NULL, 'Johannsen', NULL, NULL, NULL, 'Altenescher Ring 7', '06419-72194891', NULL, NULL, NULL, NULL, 0, 2, 1);
