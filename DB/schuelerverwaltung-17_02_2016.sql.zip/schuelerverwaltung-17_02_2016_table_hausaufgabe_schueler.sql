
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hausaufgabe_schueler`
--

CREATE TABLE `hausaufgabe_schueler` (
  `ha_id` int(11) NOT NULL,
  `skz_id` int(11) NOT NULL,
  `has_erledigt` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
