
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `klasse_zeitphase`
--

CREATE TABLE `klasse_zeitphase` (
  `kz_id` int(11) NOT NULL,
  `k_kuerzel` varchar(10) NOT NULL,
  `zph_id` int(11) NOT NULL,
  `kz_klassenlehrer` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `klasse_zeitphase`
--

INSERT INTO `klasse_zeitphase` (`kz_id`, `k_kuerzel`, `zph_id`, `kz_klassenlehrer`) VALUES
(3273, 'MKP1A', 8, NULL),
(3274, 'MKP2A', 8, NULL);
