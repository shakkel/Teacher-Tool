
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `zeitphase`
--

CREATE TABLE `zeitphase` (
  `zph_id` int(11) NOT NULL,
  `zph_bezeichnung` varchar(40) NOT NULL,
  `zph_start` date NOT NULL,
  `zph_ende` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `zeitphase`
--

INSERT INTO `zeitphase` (`zph_id`, `zph_bezeichnung`, `zph_start`, `zph_ende`) VALUES
(8, '2014_2015_02', '2015-02-04', '2015-07-22');
