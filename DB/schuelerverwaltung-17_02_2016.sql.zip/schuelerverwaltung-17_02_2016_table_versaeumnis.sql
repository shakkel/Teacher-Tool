
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `versaeumnis`
--

CREATE TABLE `versaeumnis` (
  `v_id` int(11) NOT NULL,
  `ustd_id` int(11) NOT NULL,
  `skz_id` int(11) NOT NULL,
  `v_entschuldigt` tinyint(1) NOT NULL DEFAULT '0',
  `v_abwesend` int(11) DEFAULT NULL,
  `v_verspaetung` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `versaeumnis`
--

INSERT INTO `versaeumnis` (`v_id`, `ustd_id`, `skz_id`, `v_entschuldigt`, `v_abwesend`, `v_verspaetung`) VALUES
(2810, 91, 40287, 0, 0, 15),
(2811, 91, 40288, 1, 1, NULL),
(2812, 91, 40285, 0, 1, NULL),
(2813, 91, 40290, 0, 0, 10),
(2814, 91, 40295, 1, 1, NULL);
