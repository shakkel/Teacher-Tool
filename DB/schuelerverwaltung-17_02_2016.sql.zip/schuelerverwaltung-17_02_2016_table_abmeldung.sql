
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `abmeldung`
--

CREATE TABLE `abmeldung` (
  `ab_id` int(11) NOT NULL,
  `ustd_id` int(11) NOT NULL,
  `skz_id` int(11) NOT NULL,
  `ab_zeit` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
