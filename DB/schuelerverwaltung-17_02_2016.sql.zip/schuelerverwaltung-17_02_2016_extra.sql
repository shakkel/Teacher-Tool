
--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `abmeldung`
--
ALTER TABLE `abmeldung`
  ADD PRIMARY KEY (`ab_id`),
  ADD KEY `ustd_id` (`ustd_id`),
  ADD KEY `skz_id` (`skz_id`);

--
-- Indizes für die Tabelle `fachdaten`
--
ALTER TABLE `fachdaten`
  ADD PRIMARY KEY (`f_kuerzel`);

--
-- Indizes für die Tabelle `ferien`
--
ALTER TABLE `ferien`
  ADD PRIMARY KEY (`fe_start`);

--
-- Indizes für die Tabelle `geschlecht`
--
ALTER TABLE `geschlecht`
  ADD PRIMARY KEY (`g_id`);

--
-- Indizes für die Tabelle `hausaufgabe`
--
ALTER TABLE `hausaufgabe`
  ADD PRIMARY KEY (`ha_id`),
  ADD KEY `lf_id` (`lf_id`),
  ADD KEY `kz_id` (`kz_id`),
  ADD KEY `ha_frist` (`ha_frist`);

--
-- Indizes für die Tabelle `hausaufgabe_schueler`
--
ALTER TABLE `hausaufgabe_schueler`
  ADD PRIMARY KEY (`ha_id`,`skz_id`),
  ADD KEY `c_skz_has` (`skz_id`);

--
-- Indizes für die Tabelle `klassendaten`
--
ALTER TABLE `klassendaten`
  ADD PRIMARY KEY (`k_kuerzel`);

--
-- Indizes für die Tabelle `klasse_zeitphase`
--
ALTER TABLE `klasse_zeitphase`
  ADD PRIMARY KEY (`kz_id`),
  ADD UNIQUE KEY `unique` (`k_kuerzel`,`zph_id`),
  ADD KEY `zph_id` (`zph_id`),
  ADD KEY `kz_klassenlehrer` (`kz_klassenlehrer`),
  ADD KEY `k_kuerzel` (`k_kuerzel`);

--
-- Indizes für die Tabelle `konfession`
--
ALTER TABLE `konfession`
  ADD PRIMARY KEY (`konf_id`);

--
-- Indizes für die Tabelle `kurs`
--
ALTER TABLE `kurs`
  ADD PRIMARY KEY (`ku_id`),
  ADD KEY `zph_id` (`zph_id`),
  ADD KEY `lf_id` (`lf_id`);

--
-- Indizes für die Tabelle `lehrerdaten`
--
ALTER TABLE `lehrerdaten`
  ADD PRIMARY KEY (`l_id`),
  ADD KEY `l_kuerzel` (`l_kuerzel`),
  ADD KEY `o_id` (`o_id`);

--
-- Indizes für die Tabelle `lehrer_faecher`
--
ALTER TABLE `lehrer_faecher`
  ADD PRIMARY KEY (`lf_id`),
  ADD KEY `f_kuerzel` (`f_kuerzel`),
  ADD KEY `l_id` (`l_id`);

--
-- Indizes für die Tabelle `notizen`
--
ALTER TABLE `notizen`
  ADD PRIMARY KEY (`no_id`),
  ADD KEY `no_typ` (`no_typ`),
  ADD KEY `no_fremd_id` (`no_fremd_id`);

--
-- Indizes für die Tabelle `ort`
--
ALTER TABLE `ort`
  ADD PRIMARY KEY (`o_id`);

--
-- Indizes für die Tabelle `raumdaten`
--
ALTER TABLE `raumdaten`
  ADD PRIMARY KEY (`r_kuerzel`);

--
-- Indizes für die Tabelle `schuelerdaten`
--
ALTER TABLE `schuelerdaten`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `unique` (`s_nname`,`s_vname`,`s_gebdat`,`s_geb_ort`),
  ADD KEY `st_id` (`st_id`),
  ADD KEY `g_id` (`g_id`),
  ADD KEY `konf_id` (`konf_id`);

--
-- Indizes für die Tabelle `schueler_klasse_zph`
--
ALTER TABLE `schueler_klasse_zph`
  ADD PRIMARY KEY (`skz_id`),
  ADD KEY `kz_id` (`kz_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Indizes für die Tabelle `schueler_kurs`
--
ALTER TABLE `schueler_kurs`
  ADD PRIMARY KEY (`sku_id`),
  ADD KEY `s_id` (`s_id`),
  ADD KEY `ku_id` (`ku_id`);

--
-- Indizes für die Tabelle `staat`
--
ALTER TABLE `staat`
  ADD PRIMARY KEY (`st_id`);

--
-- Indizes für die Tabelle `unterricht`
--
ALTER TABLE `unterricht`
  ADD PRIMARY KEY (`u_id`),
  ADD KEY `lf_id` (`lf_id`),
  ADD KEY `r_kuerzel` (`r_kuerzel`),
  ADD KEY `u_doppelstunde` (`u_doppelstunde`),
  ADD KEY `kz_id` (`kz_id`),
  ADD KEY `ku_id` (`ku_id`);

--
-- Indizes für die Tabelle `unterrichtsstunde`
--
ALTER TABLE `unterrichtsstunde`
  ADD PRIMARY KEY (`ustd_id`),
  ADD UNIQUE KEY `unique_klasse` (`u_stunde`,`ustd_datum`,`kz_id`),
  ADD KEY `ustd_vertretungslehrer` (`ustd_vertretungslehrer`),
  ADD KEY `lf_id` (`lf_id`),
  ADD KEY `kz_id` (`kz_id`),
  ADD KEY `ku_id` (`ku_id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indizes für die Tabelle `versaeumnis`
--
ALTER TABLE `versaeumnis`
  ADD PRIMARY KEY (`v_id`),
  ADD UNIQUE KEY `schueler_stunde` (`ustd_id`,`skz_id`),
  ADD KEY `skz_id` (`skz_id`),
  ADD KEY `v_entschuldigt` (`v_entschuldigt`),
  ADD KEY `ustd_id` (`ustd_id`);

--
-- Indizes für die Tabelle `zeitphase`
--
ALTER TABLE `zeitphase`
  ADD PRIMARY KEY (`zph_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `abmeldung`
--
ALTER TABLE `abmeldung`
  MODIFY `ab_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `geschlecht`
--
ALTER TABLE `geschlecht`
  MODIFY `g_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `hausaufgabe`
--
ALTER TABLE `hausaufgabe`
  MODIFY `ha_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `klasse_zeitphase`
--
ALTER TABLE `klasse_zeitphase`
  MODIFY `kz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3275;
--
-- AUTO_INCREMENT für Tabelle `konfession`
--
ALTER TABLE `konfession`
  MODIFY `konf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT für Tabelle `kurs`
--
ALTER TABLE `kurs`
  MODIFY `ku_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `lehrerdaten`
--
ALTER TABLE `lehrerdaten`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT für Tabelle `lehrer_faecher`
--
ALTER TABLE `lehrer_faecher`
  MODIFY `lf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT für Tabelle `notizen`
--
ALTER TABLE `notizen`
  MODIFY `no_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT für Tabelle `ort`
--
ALTER TABLE `ort`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19671;
--
-- AUTO_INCREMENT für Tabelle `schuelerdaten`
--
ALTER TABLE `schuelerdaten`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6676;
--
-- AUTO_INCREMENT für Tabelle `schueler_klasse_zph`
--
ALTER TABLE `schueler_klasse_zph`
  MODIFY `skz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40315;
--
-- AUTO_INCREMENT für Tabelle `schueler_kurs`
--
ALTER TABLE `schueler_kurs`
  MODIFY `sku_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `unterricht`
--
ALTER TABLE `unterricht`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT für Tabelle `unterrichtsstunde`
--
ALTER TABLE `unterrichtsstunde`
  MODIFY `ustd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT für Tabelle `versaeumnis`
--
ALTER TABLE `versaeumnis`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2815;
--
-- AUTO_INCREMENT für Tabelle `zeitphase`
--
ALTER TABLE `zeitphase`
  MODIFY `zph_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `abmeldung`
--
ALTER TABLE `abmeldung`
  ADD CONSTRAINT `c_skz_ab` FOREIGN KEY (`skz_id`) REFERENCES `schueler_klasse_zph` (`skz_id`),
  ADD CONSTRAINT `c_unterrichtsstunde_ab` FOREIGN KEY (`ustd_id`) REFERENCES `unterrichtsstunde` (`ustd_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `hausaufgabe`
--
ALTER TABLE `hausaufgabe`
  ADD CONSTRAINT `c_klasse_zeitphase_ha` FOREIGN KEY (`kz_id`) REFERENCES `klasse_zeitphase` (`kz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `c_lehrer_faecher_ha` FOREIGN KEY (`lf_id`) REFERENCES `lehrer_faecher` (`lf_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `hausaufgabe_schueler`
--
ALTER TABLE `hausaufgabe_schueler`
  ADD CONSTRAINT `c_hausaufgabe` FOREIGN KEY (`ha_id`) REFERENCES `hausaufgabe` (`ha_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `c_skz_has` FOREIGN KEY (`skz_id`) REFERENCES `schueler_klasse_zph` (`skz_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `klasse_zeitphase`
--
ALTER TABLE `klasse_zeitphase`
  ADD CONSTRAINT `c_k_kuerzel` FOREIGN KEY (`k_kuerzel`) REFERENCES `klassendaten` (`k_kuerzel`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `c_lehrerdaten` FOREIGN KEY (`kz_klassenlehrer`) REFERENCES `lehrerdaten` (`l_id`),
  ADD CONSTRAINT `c_zeitphase` FOREIGN KEY (`zph_id`) REFERENCES `zeitphase` (`zph_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `kurs`
--
ALTER TABLE `kurs`
  ADD CONSTRAINT `kurs_lehrer_faecher` FOREIGN KEY (`lf_id`) REFERENCES `lehrer_faecher` (`lf_id`),
  ADD CONSTRAINT `kurs_zeitphase` FOREIGN KEY (`zph_id`) REFERENCES `zeitphase` (`zph_id`);

--
-- Constraints der Tabelle `lehrerdaten`
--
ALTER TABLE `lehrerdaten`
  ADD CONSTRAINT `c_ort_lehrer` FOREIGN KEY (`o_id`) REFERENCES `ort` (`o_id`);

--
-- Constraints der Tabelle `lehrer_faecher`
--
ALTER TABLE `lehrer_faecher`
  ADD CONSTRAINT `c_fachdaten` FOREIGN KEY (`f_kuerzel`) REFERENCES `fachdaten` (`f_kuerzel`),
  ADD CONSTRAINT `c_lehrerdaten_fach` FOREIGN KEY (`l_id`) REFERENCES `lehrerdaten` (`l_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `schuelerdaten`
--
ALTER TABLE `schuelerdaten`
  ADD CONSTRAINT `c_geschlecht` FOREIGN KEY (`g_id`) REFERENCES `geschlecht` (`g_id`),
  ADD CONSTRAINT `c_konfession` FOREIGN KEY (`konf_id`) REFERENCES `konfession` (`konf_id`);

--
-- Constraints der Tabelle `schueler_klasse_zph`
--
ALTER TABLE `schueler_klasse_zph`
  ADD CONSTRAINT `c_klasse_zeitphase` FOREIGN KEY (`kz_id`) REFERENCES `klasse_zeitphase` (`kz_id`),
  ADD CONSTRAINT `c_schuelerdaten` FOREIGN KEY (`s_id`) REFERENCES `schuelerdaten` (`s_id`);

--
-- Constraints der Tabelle `schueler_kurs`
--
ALTER TABLE `schueler_kurs`
  ADD CONSTRAINT `schueler_kurs_ku_id` FOREIGN KEY (`ku_id`) REFERENCES `kurs` (`ku_id`),
  ADD CONSTRAINT `schueler_kurs_s_id` FOREIGN KEY (`s_id`) REFERENCES `schuelerdaten` (`s_id`);

--
-- Constraints der Tabelle `unterricht`
--
ALTER TABLE `unterricht`
  ADD CONSTRAINT `c_klasse_zeitphase_unterricht` FOREIGN KEY (`kz_id`) REFERENCES `klasse_zeitphase` (`kz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `c_lf_unterricht` FOREIGN KEY (`lf_id`) REFERENCES `lehrer_faecher` (`lf_id`),
  ADD CONSTRAINT `c_raumdaten` FOREIGN KEY (`r_kuerzel`) REFERENCES `raumdaten` (`r_kuerzel`),
  ADD CONSTRAINT `unterricht_ku_id` FOREIGN KEY (`ku_id`) REFERENCES `kurs` (`ku_id`);

--
-- Constraints der Tabelle `unterrichtsstunde`
--
ALTER TABLE `unterrichtsstunde`
  ADD CONSTRAINT `c_klasse_zeitphase_ustd` FOREIGN KEY (`kz_id`) REFERENCES `klasse_zeitphase` (`kz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `c_lehrer_faecher_ustd` FOREIGN KEY (`lf_id`) REFERENCES `lehrer_faecher` (`lf_id`),
  ADD CONSTRAINT `c_unterrichtsstunde_ku_id` FOREIGN KEY (`ku_id`) REFERENCES `kurs` (`ku_id`);

--
-- Constraints der Tabelle `versaeumnis`
--
ALTER TABLE `versaeumnis`
  ADD CONSTRAINT `c_skz` FOREIGN KEY (`skz_id`) REFERENCES `schueler_klasse_zph` (`skz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `c_unterrichtsstunde_vers` FOREIGN KEY (`ustd_id`) REFERENCES `unterrichtsstunde` (`ustd_id`) ON DELETE CASCADE ON UPDATE CASCADE;
